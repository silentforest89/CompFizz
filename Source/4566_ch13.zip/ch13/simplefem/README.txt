This is a simple finite element program for elastic deformation.
It works for the ifort compiler.
The program gf_fem works for gfortran...

