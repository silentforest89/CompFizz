#include <stdio.h>
#include <math.h>
#define TRUE 1
#define FALSE 0


FILE *FP;
static double *Values;
static int ValNum, SegNum, MaxNum;
short int Stop;

void newElem(FP, Cnt)
int Cnt;
FILE *FP;
{
  double newVal;

  if (Stop==FALSE)
  {
    if(fscanf (FP, "%lf", &newVal)==EOF)
    {
      Stop=TRUE;
      MaxNum = Cnt;
      Values = (double *) calloc(MaxNum, sizeof(double)); 
    }
    else
    {
      newElem(FP, Cnt+1);
      Values[Cnt] = newVal;
    }
  }
}
    
    
     



void
ReadMags()
{
  int i;
  double res, NewVal, *DPtr;
  char FileName[7];

  printf("Give filename, number of blocks. \n");
  scanf ("%s %d", FileName, &SegNum);
  
  FP = fopen(FileName, "r");
  Stop = FALSE;
  newElem(FP, 0);
  
/*
  res = 0;
  for (i=0; i<MaxNum; i++)
  {
    res = res + Values[i];
  } 
  res = res/MaxNum;
  printf ("Average = %lf\n", res);
*/
}


void 
CalcCorr()
{
  int i, k, BlockSize;
  double MeanVal, SqVal, *BlockMean, *BlockSq, MeanVar, VarDev;
  
  BlockMean = (double *) calloc(SegNum, sizeof(double));
  BlockSq   = (double *) calloc(SegNum, sizeof(double));
  BlockSize = MaxNum/SegNum;
  for (i=0; i<SegNum; i++)
  {
    BlockMean[i] = 0;
    BlockSq[i] = 0;
    for (k=0; k<BlockSize; k++)
    {
      BlockMean[i] = BlockMean[i] = BlockMean[i] + Values[i*BlockSize+k];
      BlockSq[i] = BlockSq[i] + 
                        Values[i*BlockSize+k]*Values[i*BlockSize+k];
    }
    BlockMean[i] = BlockMean[i]/BlockSize;
    BlockSq[i] = BlockSq[i]/BlockSize-BlockMean[i]*BlockMean[i];
    BlockSq[i] = sqrt(BlockSq[i]);
  }
  MeanVal = 0;
  MeanVar=0;
  VarDev=0;
  SqVal = 0;
  for (i=0; i<SegNum; i++)
  {
    MeanVal = MeanVal + BlockMean[i];
    MeanVar = MeanVar + BlockSq[i];  
    SqVal = SqVal + BlockMean[i]*BlockMean[i];
    VarDev = VarDev + BlockSq[i]*BlockSq[i];
  }
  MeanVal = MeanVal/SegNum;
  MeanVar = MeanVar/SegNum;
  SqVal = SqVal/SegNum-MeanVal*MeanVal;
  SqVal = SqVal/SegNum;
  VarDev = VarDev/SegNum - MeanVar*MeanVar;
  VarDev = VarDev/SegNum;
  printf("Average: %lf +/- %lf\n", MeanVal, sqrt(SqVal));
  printf("Variance: %lf +/- %lf\n", MeanVar, sqrt(VarDev));
}
 

void
main()
{
  ReadMags();
  CalcCorr();
}
